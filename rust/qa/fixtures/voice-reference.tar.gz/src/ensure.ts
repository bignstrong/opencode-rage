import { downloadModel } from "../lib/download.js";
import {
  VoiceRuntime,
  ensureManagedRecorder,
  getRecorderStatus,
  probeRecorder,
} from "../lib/engine.js";
import { getEngineStatus, installManagedEngine } from "../lib/engines.js";
import { getModel, getModelPath, isModelDownloaded } from "../lib/models.js";
import { formatBytes } from "./formatters.ts";
import { resolveUiLanguage, type UiLanguage } from "./i18n.ts";
import type { VoiceSettings } from "./settings.ts";

export type ToastFn = (message: string, variant?: "info" | "success" | "warning" | "error") => void;
interface StatusCopy {
  hint: string;
  detail: string;
}
export interface DownloadStatus extends StatusCopy {
  phase: "downloading" | "verifying" | "ready" | "failed";
  translations?: Record<UiLanguage, StatusCopy>;
}
export function localizeDownloadStatus(
  value: DownloadStatus,
  language: UiLanguage,
): DownloadStatus {
  const copy = value.translations?.[language];
  return copy && (copy.hint !== value.hint || copy.detail !== value.detail)
    ? { ...value, ...copy }
    : value;
}
export type DownloadStatusFn = (modelId: string, status: DownloadStatus) => void;
export class ReportedDownloadError extends Error {}

export interface EnsureEnv {
  options: Record<string, unknown>;
  settings: VoiceSettings;
  getSettings?: () => VoiceSettings;
  toast: ToastFn;
  downloadStatus?: DownloadStatusFn;
  download?: typeof downloadModel;
  installEngine?: typeof installManagedEngine;
  ensureRecorder?: typeof ensureManagedRecorder;
}

interface DownloadFlight {
  result: Promise<boolean>;
  listeners: Map<DownloadStatusFn, EnsureEnv>;
  message?: DownloadStatus;
}

const downloads = new Map<string, DownloadFlight>();

function uiLanguage(env: EnsureEnv) {
  return resolveUiLanguage((env.getSettings?.() ?? env.settings).uiLanguage);
}

export async function ensureDownloaded(
  env: EnsureEnv,
  model = getModel(env.settings.model),
): Promise<boolean> {
  const path = getModelPath(model, env.options, env.settings);
  const current = downloads.get(path);
  if (current) {
    if (env.downloadStatus && !current.listeners.has(env.downloadStatus)) {
      current.listeners.set(env.downloadStatus, env);
      if (current.message !== undefined)
        env.downloadStatus(model.id, localizeDownloadStatus(current.message, uiLanguage(env)));
    }
    return current.result;
  }
  if (isModelDownloaded(model, env.options, env.settings)) return true;

  // Register the flight before the first status callback can trigger another caller.
  const flight: DownloadFlight = {
    listeners: new Map(env.downloadStatus ? [[env.downloadStatus, env]] : []),
    result: Promise.resolve()
      .then(() =>
        runDownload(env, model, (message) => {
          if (flight.message?.detail === message.detail && flight.message.hint === message.hint)
            return;
          flight.message = message;
          for (const [listener, subscriber] of flight.listeners)
            listener(model.id, localizeDownloadStatus(message, uiLanguage(subscriber)));
        }),
      )
      .finally(() => downloads.delete(path)),
  };
  downloads.set(path, flight);
  return flight.result;
}

async function runDownload(
  env: EnsureEnv,
  model: ReturnType<typeof getModel>,
  report: (status: DownloadStatus) => void,
): Promise<boolean> {
  const download = env.download ?? downloadModel;
  const language = () => uiLanguage(env);
  const emit = (phase: DownloadStatus["phase"], en: StatusCopy, ru: StatusCopy) => {
    const translations = { en, ru };
    report({ phase, ...translations[language()], translations });
  };
  let bytes = 0;
  let total = 0;
  let lastUpdate = -Infinity;
  let timer: ReturnType<typeof setTimeout>;
  const clearPending = () => {
    clearTimeout(timer);
    timer = undefined;
  };
  const size = (n: number, lang: UiLanguage) =>
    lang === "ru"
      ? formatBytes(n).replace("MB", "МБ").replace("GB", "ГБ").replace(".", ",")
      : formatBytes(n);
  const counts = (lang: UiLanguage) =>
    total > 0 ? `${size(bytes, lang)} / ${size(total, lang)}` : size(bytes, lang);
  const showBytes = () => {
    clearPending();
    lastUpdate = performance.now();
    const amount = (lang: UiLanguage) =>
      total > 0 ? ` ${Math.floor((bytes / total) * 100)}%` : ` · ${size(bytes, lang)}`;
    emit(
      "downloading",
      { hint: `Downloading model${amount("en")}`, detail: counts("en") },
      { hint: `Загрузка модели${amount("ru")}`, detail: counts("ru") },
    );
  };
  try {
    emit(
      "downloading",
      { hint: "Downloading model…", detail: "Downloading…" },
      { hint: "Загрузка модели…", detail: "Загрузка…" },
    );
    env.toast(
      language() === "ru"
        ? `Скачиваю ${model.name}. Прогресс смотри под полем ввода.`
        : `Downloading ${model.name}. See progress below the input field.`,
      "info",
    );
    await download(model, env.options, env.settings, {
      retries: 5,
      onProgress: (p: { state: string; downloaded: number; total: number }) => {
        if (p.state === "verifying") {
          clearPending();
          emit(
            "verifying",
            { hint: "Verifying…", detail: "Verifying SHA256" },
            { hint: "Проверка…", detail: "Проверка SHA256" },
          );
        }
        if (p.state !== "downloading") return;
        bytes = p.downloaded;
        total = p.total;
        const wait = 1500 - (performance.now() - lastUpdate);
        if (wait <= 0) showBytes();
        else timer ??= setTimeout(showBytes, wait);
      },
      onRetry: ({ nextAttempt, attempts }: { nextAttempt: number; attempts: number }) => {
        clearPending();
        lastUpdate = -Infinity;
        const attempt = (lang: UiLanguage) =>
          `${nextAttempt}/${attempts}${bytes ? ` · ${counts(lang)}` : ""}`;
        emit(
          "downloading",
          { hint: "Dictation · retrying download", detail: `Attempt ${attempt("en")}` },
          { hint: "Диктовка · повтор загрузки", detail: `Попытка ${attempt("ru")}` },
        );
      },
    });
    emit(
      "ready",
      { hint: "Dictation ready", detail: "Ready" },
      { hint: "Диктовка готова", detail: "Готова" },
    );
    return true;
  } catch (error) {
    const detail = error instanceof Error ? error.message : String(error);
    emit(
      "failed",
      { hint: "Download failed · /voice-settings", detail },
      { hint: "Сбой загрузки · /voice-settings", detail },
    );
    if (!env.downloadStatus) throw error;
    throw new ReportedDownloadError(detail, { cause: error });
  } finally {
    clearPending();
  }
}

export async function ensureEngineReady(
  env: EnsureEnv,
  model = getModel(env.settings.model),
): Promise<boolean> {
  const engineId = model.engine;
  const commandOptions = { ...env.options, downloadDir: env.settings.downloadDir };
  const current = getEngineStatus(engineId, env.options, env.settings);
  if (current.resolvedBinary) {
    const { probeEngine } = await import("../lib/engines.js");
    if ((await probeEngine(engineId, current.resolvedBinary)).ok) return true;
  }
  const install = env.installEngine ?? installManagedEngine;
  const russian = () => uiLanguage(env) === "ru";
  env.toast(russian() ? `Установка ${engineId}…` : `Installing ${engineId}...`);
  await install(engineId, commandOptions, env.settings, {
    retries: 5,
    onRetry: ({
      error,
      nextAttempt,
      attempts,
    }: {
      error: unknown;
      nextAttempt: number;
      attempts: number;
    }) =>
      env.toast(
        `${russian() ? "Повтор установки движка" : "Engine install retry"} ${nextAttempt}/${attempts}: ${error instanceof Error ? error.message : String(error)}`,
        "warning",
      ),
  });
  env.toast(russian() ? `${engineId} установлен` : `${engineId} installed`, "success");
  return true;
}

export async function ensureRecorderReady(env: EnsureEnv): Promise<boolean> {
  if (process.platform !== "win32") return true;
  const commandOptions = {
    ...env.options,
    downloadDir: env.settings.downloadDir,
    skipFfmpegStaticInstall: true,
  };
  const current = getRecorderStatus(commandOptions, env.settings);
  if (current.resolvedBinary && (await probeRecorder(current.resolvedBinary)).ok) return true;
  const ensure = env.ensureRecorder ?? ensureManagedRecorder;
  const russian = () => uiLanguage(env) === "ru";
  env.toast(
    russian() ? "Установка программы записи для Windows…" : "Installing local Windows recorder...",
  );
  await ensure(commandOptions, env.settings, {
    retries: 5,
    onRetry: ({
      error,
      nextAttempt,
      attempts,
    }: {
      error: unknown;
      nextAttempt: number;
      attempts: number;
    }) =>
      env.toast(
        `${russian() ? "Повтор установки программы записи" : "Recorder install retry"} ${nextAttempt}/${attempts}: ${error instanceof Error ? error.message : String(error)}`,
        "warning",
      ),
  });
  env.toast(
    russian() ? "Программа записи для Windows установлена" : "Windows recorder installed",
    "success",
  );
  return true;
}

export type { VoiceRuntime };
