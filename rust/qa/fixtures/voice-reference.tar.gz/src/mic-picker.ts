import {
  MouseButton,
  TextAttributes,
  type ColorInput,
  type KeyEvent,
  type MouseEvent,
} from "@opentui/core";
import { jsx } from "@opentui/solid/jsx-runtime";
import { createMemo, createSignal, For, onCleanup, onMount } from "solid-js";
import type { Plugin } from "@opencode/plugin/tui";
import { watchMicrophones } from "./mic-picker-watch.js";

export type MicRow = { title: string; value: string; description?: string };
export type MicDialog = Pick<Plugin.Context["ui"]["dialog"], "show" | "clear">;
export type MicTheme = { text: { base: ColorInput; muted: ColorInput } };

// The suffix of a UID selector is its last known display name and can change.
export const micIdentity = (value: string) => value.match(/^:uid:[^:]+:/)?.[0] ?? value;

export function liveMicPicker(
  dialog: MicDialog,
  menu: {
    title: string;
    placeholder: string;
    current: string;
    rows: (devices: MicRow[]) => MicRow[];
    list: (signal: AbortSignal) => Promise<MicRow[]>;
    ru: boolean;
    theme?: MicTheme;
  },
): Promise<string | undefined> {
  return new Promise((resolve) => {
    let stop: (() => void) | undefined;
    let closed = false;
    function finish(value?: string) {
      if (closed) return;
      closed = true;
      stop?.();
      resolve(value);
    }
    function choose(value?: string) {
      if (closed) return;
      finish(value);
      dialog.clear();
    }
    dialog.show(
      () => {
        const [devices, setDevices] = createSignal<MicRow[]>([]);
        const [filter, setFilter] = createSignal("");
        const [cursor, setCursor] = createSignal<string | undefined>(micIdentity(menu.current));
        let pressed: string | undefined;
        const rows = createMemo(() => {
          const query = filter().trim().toLowerCase();
          return menu.rows(devices()).filter((row) => row.title.toLowerCase().includes(query));
        });
        const index = createMemo(() =>
          cursor() === undefined
            ? 0
            : rows().findIndex((row) => micIdentity(row.value) === cursor()),
        );
        const visible = () => {
          const start = Math.max(0, index() - 7);
          return rows().slice(start, start + 8);
        };
        function move(delta: number) {
          const next = Math.max(0, Math.min(rows().length - 1, index() + delta));
          if (rows()[next]) setCursor(micIdentity(rows()[next].value));
        }
        function keyDown(key: KeyEvent) {
          if (key.name === "up" || (key.ctrl && key.name === "p")) move(-1);
          else if (key.name === "down" || (key.ctrl && key.name === "n")) move(1);
          else if (key.name === "return") {
            if (rows()[index()]) choose(rows()[index()].value);
          } else if (key.name === "escape") choose();
          else return;
          key.preventDefault();
          key.stopPropagation();
        }
        onMount(() => {
          if (!closed)
            stop = watchMicrophones(menu.list, (next: MicRow[]) => {
              setDevices(next);
              if (cursor() === undefined && rows()[0]) setCursor(micIdentity(rows()[0].value));
            });
        });
        onCleanup(() => finish());
        return jsx("box", {
          paddingX: 2,
          flexDirection: "column",
          onMouseUp() {
            pressed = undefined;
          },
          onMouseDrag() {
            pressed = undefined;
          },
          children: [
            jsx("text", {
              content: menu.title,
              fg: menu.theme?.text.base,
              attributes: TextAttributes.BOLD,
            }),
            jsx("input", {
              id: "voice-mic-filter",
              focused: true,
              placeholder: menu.placeholder,
              textColor: menu.theme?.text.base,
              placeholderColor: menu.theme?.text.muted,
              onInput(value: string) {
                setFilter(value);
                // Pin the first matching result too: discovery must never retarget Enter.
                const row = rows()[Math.max(0, index())];
                setCursor(row && micIdentity(row.value));
              },
              onKeyDown: keyDown,
            }),
            jsx("box", {
              flexDirection: "column",
              onMouseScroll(event: MouseEvent) {
                if (event.scroll?.direction === "up") move(-1);
                if (event.scroll?.direction === "down") move(1);
              },
              children: jsx(For, {
                get each() {
                  return visible();
                },
                fallback: jsx("text", {
                  content: menu.ru ? "Ничего не найдено" : "No matches",
                  fg: menu.theme?.text.muted,
                }),
                children: (row: MicRow) =>
                  jsx("text", {
                    height: 1,
                    selectable: false,
                    wrapMode: "none",
                    fg: menu.theme?.text.base,
                    get attributes() {
                      return row.value === rows()[index()]?.value ? TextAttributes.INVERSE : 0;
                    },
                    content: row.description ? `${row.title} · ${row.description}` : row.title,
                    onMouseDown(event: MouseEvent) {
                      if (event.button === MouseButton.LEFT) pressed = micIdentity(row.value);
                      event.preventDefault();
                    },
                    onMouseUp(event: MouseEvent) {
                      if (
                        event.button !== MouseButton.LEFT ||
                        event.isDragging ||
                        pressed !== micIdentity(row.value)
                      )
                        return;
                      const current = rows().find((item) => micIdentity(item.value) === pressed);
                      if (current) choose(current.value);
                    },
                  }),
              }),
            }),
            jsx("text", {
              content: menu.ru
                ? "↑↓ Выбор · Enter Сохранить · Esc Назад"
                : "↑↓ Navigate · Enter Choose · Esc Back",
              fg: menu.theme?.text.muted,
            }),
          ],
        });
      },
      () => finish(),
    );
  });
}
