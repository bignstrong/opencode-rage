export type UiLanguage = "en" | "ru";
export { resolveUiLanguage } from "../lib/i18n.js";
